let parser = new DOMParser();
let currentTransportState = "PLAYING";
let coverurl = "";

function unEscape(a) {
    a = a.replace(/&lt;/g , "<");	 
    a = a.replace(/&gt;/g , ">");     
    a = a.replace(/&quot;/g , "\"");  
    a = a.replace(/&#39;/g , "\'");   
    a = a.replace(/&amp;/g , "&");
    return a;
}

function getCoverart(url) {
    if (url.startsWith("http") === false) {
            url = "http://192.168.68.113:1400" + url;
    }
    
    url = decodeURIComponent(url);
    url = unEscape(url);
    if(url === coverurl) {
        return;
    }
    
    coverurl = url;
    
    fetch(url)
        .then(response => response.blob())
        .then(imageBlob => {
        let img = document.createElement('img');
        img.src = window.URL.createObjectURL(imageBlob);
        img.width = "300";
        img.height = "300";
        let ca = document.getElementById("coverart");
        ca.innerHTML = "";
        ca.appendChild(img);
        })
        .catch( function(error) {
            console.log(error);
        });
}

function getMeta() {
    
  chrome.runtime.sendMessage('getMeta', (response) => {  
    b = parser.parseFromString(response, "text/xml");
    let meta = b.getElementsByTagName("TrackMetaData")[0].innerHTML;
    displayMeta(meta);  
      
  });  
    
  chrome.runtime.sendMessage('getStatus', (response) => {  
    b = parser.parseFromString(response, "text/xml");
    currentTransportState = b.getElementsByTagName("CurrentTransportState")[0].innerHTML;
    console.log(currentTransportState);
    if(currentTransportState === 'PLAYING') {
        document.getElementById("playpause").src = "icons/pause.svg";
    } else {
        document.getElementById("playpause").src = "icons/play.svg";
    }
  });    
}

function displayMeta(a){
    meta = unEscape(a)
    let title = "";
    let creator = "";
    let subtitle = "";
    let artist = "";
    let album = "";
    let url = "";
    let channel = "0";
    let rp = {};
    
    b = parser.parseFromString(meta,"text/xml");
    try {
        title = b.getElementsByTagName("dc:title")[0].innerHTML;
        document.getElementById("title").innerHTML = title;
        try {
            creator = b.getElementsByTagName("dc:creator")[0].innerHTML;
        } catch(error) {creator="";}
        
    } catch(error) {console.log(error)}
    
    try {
        subtitle = b.getElementsByTagName("dc:subtitle")[0].innerHTML;
        document.getElementById("subtitle").innerHTML = subtitle;
    } catch(error) {subtitle="";}
    
    try {
        artist = b.getElementsByTagName("upnp:artist")[0].innerHTML;
        document.getElementById("artist").innerHTML = artist;
    } catch(error) {artist="";}

    try {
        artist = b.getElementsByTagName("dc:creator")[0].innerHTML;
        document.getElementById("artist").innerHTML = artist;
    } catch(error) {artist="";}
    
    try {
        album = b.getElementsByTagName("upnp:album")[0].innerHTML;
        document.getElementById("album").innerHTML = album;
    } catch(error) {album="";}

    try {
        url = b.getElementsByTagName("upnp:albumArtURI")[0].innerHTML;
        getCoverart(url);
    }    
    catch (error) {console.log(error)}   
    
};    

chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {  
    setInterval(getMeta,1000);
    getMeta();
});

document.getElementById("prev").addEventListener("click",function(){

    chrome.runtime.sendMessage('Prev',function(response) { });
});

document.getElementById("playpause").addEventListener("click",function(){
    let cmd = 'Pause';
    if(currentTransportState != 'PLAYING') {
        cmd = 'Play';
    }    

    chrome.runtime.sendMessage(cmd,function(response) { });
});

document.getElementById("next").addEventListener("click",function(){

    chrome.runtime.sendMessage('Next',function(response) { });
    getMeta();
});
